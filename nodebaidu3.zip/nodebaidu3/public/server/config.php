<?php

	header("Content-type: application/json; charset=utf-8");

	define('HOST', 'localhost:8888');

	define('USERNAME', 'root');

	define('PASSWORD', 'root');

?>